export const PrimerCoponente = () => {
  const nombre = "Juan Pablo"
  const wed = "DobleBs7.com"
  return (
    <div>
      <p>MI Nombre es:{nombre}</p>
      <p> mi wed es:{wed}</p>
    </div>
  )
}

