export const segundoComponente = () => {
  return <div>segundoComponente</div>
}

