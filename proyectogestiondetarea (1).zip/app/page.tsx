"use client"

import  from "../frontend/frontend/src/index"

export default function SyntheticV0PageForDeployment() {
  return < />
}