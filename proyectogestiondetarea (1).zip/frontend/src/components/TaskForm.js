"use client"

import { useState } from "react"
import { useTaskContext } from "../context/TaskContext"
import { Alert } from "./Alert"

/**
 * Componente para crear o editar tareas
 * @component
 */
const TaskForm = ({ taskToEdit = null }) => {
  // Obtener funciones y estado del contexto
  const { createTask, updateTask, error, loading, clearError } = useTaskContext()

  // Estado inicial del formulario
  const [formData, setFormData] = useState({
    title: taskToEdit ? taskToEdit.title : "",
    description: taskToEdit ? taskToEdit.description : "",
    dueDate: taskToEdit ? new Date(taskToEdit.dueDate).toISOString().split("T")[0] : "",
    priority: taskToEdit ? taskToEdit.priority : "media",
    status: taskToEdit ? taskToEdit.status : "pendiente",
  })

  // Estado para mensajes de éxito
  const [successMessage, setSuccessMessage] = useState("")

  /**
   * Maneja cambios en los campos del formulario
   * @param {Event} e - Evento del cambio
   */
  const handleChange = (e) => {
    const { name, value } = e.target
    setFormData({
      ...formData,
      [name]: value,
    })
  }

  /**
   * Maneja el envío del formulario
   * @param {Event} e - Evento del formulario
   */
  const handleSubmit = async (e) => {
    e.preventDefault()

    // Limpiar mensajes previos
    clearError()
    setSuccessMessage("")

    try {
      if (taskToEdit) {
        // Actualizar tarea existente
        await updateTask(taskToEdit._id, formData)
        setSuccessMessage("¡Tarea actualizada con éxito!")
      } else {
        // Crear nueva tarea
        await createTask(formData)
        setSuccessMessage("¡Tarea creada con éxito!")

        // Limpiar formulario después de crear
        setFormData({
          title: "",
          description: "",
          dueDate: "",
          priority: "media",
          status: "pendiente",
        })
      }
    } catch (err) {
      // Los errores son manejados por el contexto
      console.error("Error en el formulario:", err)
    }
  }

  return (
    <div className="task-form">
      <h2>{taskToEdit ? "Editar Tarea" : "Crear Nueva Tarea"}</h2>

      {/* Mostrar mensajes de error o éxito */}
      {error && <Alert type="error" message={error} />}
      {successMessage && <Alert type="success" message={successMessage} />}

      <form onSubmit={handleSubmit}>
        <div className="form-group">
          <label htmlFor="title">Título</label>
          <input
            type="text"
            id="title"
            name="title"
            value={formData.title}
            onChange={handleChange}
            placeholder="Título de la tarea"
            required
          />
        </div>

        <div className="form-group">
          <label htmlFor="description">Descripción</label>
          <textarea
            id="description"
            name="description"
            value={formData.description}
            onChange={handleChange}
            placeholder="Describe la tarea en detalle"
            required
          />
        </div>

        <div className="form-group">
          <label htmlFor="dueDate">Fecha de vencimiento</label>
          <input type="date" id="dueDate" name="dueDate" value={formData.dueDate} onChange={handleChange} required />
        </div>

        <div className="form-group">
          <label htmlFor="priority">Prioridad</label>
          <select id="priority" name="priority" value={formData.priority} onChange={handleChange}>
            <option value="alta">Alta</option>
            <option value="media">Media</option>
            <option value="baja">Baja</option>
          </select>
        </div>

        {taskToEdit && (
          <div className="form-group">
            <label htmlFor="status">Estado</label>
            <select id="status" name="status" value={formData.status} onChange={handleChange}>
              <option value="pendiente">Pendiente</option>
              <option value="en progreso">En progreso</option>
              <option value="completada">Completada</option>
            </select>
          </div>
        )}

        <button type="submit" disabled={loading} className={loading ? "button-loading" : ""}>
          {loading ? "Procesando..." : taskToEdit ? "Actualizar Tarea" : "Crear Tarea"}
        </button>
      </form>
    </div>
  )
}

export default TaskForm

