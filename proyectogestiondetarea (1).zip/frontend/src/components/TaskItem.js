"use client"

import { useState } from "react"
import { useTaskContext } from "../context/TaskContext"
import { Trash, Edit, Check, X } from "lucide-react" // Importar iconos

/**
 * Componente que muestra una tarea individual
 * @component
 * @param {Object} props - Propiedades del componente
 * @param {Object} props.task - Datos de la tarea
 */
const TaskItem = ({ task }) => {
  const { deleteTask, updateTask } = useTaskContext()
  const [isDeleting, setIsDeleting] = useState(false)
  const [showConfirmation, setShowConfirmation] = useState(false)

  /**
   * Formatea la fecha para mostrarla
   * @param {string} dateString - Fecha en formato string
   * @returns {string} - Fecha formateada
   */
  const formatDate = (dateString) => {
    const options = { year: "numeric", month: "long", day: "numeric" }
    return new Date(dateString).toLocaleDateString(undefined, options)
  }

  /**
   * Maneja el cambio de estado de una tarea
   * @param {string} newStatus - Nuevo estado
   */
  const handleStatusChange = async () => {
    const newStatus = task.status === "completada" ? "pendiente" : "completada"
    await updateTask(task._id, { ...task, status: newStatus })
  }

  /**
   * Maneja la eliminación de una tarea
   */
  const handleDelete = async () => {
    setIsDeleting(true)
    try {
      await deleteTask(task._id)
    } catch (error) {
      console.error("Error al eliminar:", error)
    } finally {
      setIsDeleting(false)
      setShowConfirmation(false)
    }
  }

  /**
   * Determina la clase CSS según la prioridad
   * @returns {string} - Clase CSS
   */
  const getPriorityClass = () => {
    switch (task.priority) {
      case "alta":
        return "priority-high"
      case "media":
        return "priority-medium"
      case "baja":
        return "priority-low"
      default:
        return ""
    }
  }

  return (
    <li className={`task-item ${task.status} ${getPriorityClass()}`}>
      <div className="task-content">
        <div className="task-header">
          <h3 className="task-title">{task.title}</h3>
          <div className="task-badges">
            <span className={`priority-badge ${getPriorityClass()}`}>{task.priority}</span>
            <span className={`status-badge status-${task.status}`}>{task.status}</span>
          </div>
        </div>

        <p className="task-description">{task.description}</p>

        <div className="task-meta">
          <p className="task-date">
            <span className="meta-label">Fecha límite:</span> {formatDate(task.dueDate)}
          </p>
        </div>
      </div>

      <div className="task-actions">
        <button
          className="action-button status-toggle"
          onClick={handleStatusChange}
          title={task.status === "completada" ? "Marcar como pendiente" : "Marcar como completada"}
        >
          {task.status === "completada" ? <X size={18} /> : <Check size={18} />}
        </button>

        <button
          className="action-button edit"
          onClick={() => (window.location.href = `/edit-task/${task._id}`)}
          title="Editar tarea"
        >
          <Edit size={18} />
        </button>

        {showConfirmation ? (
          <div className="confirmation-buttons">
            <button className="confirm-yes" onClick={handleDelete} disabled={isDeleting}>
              {isDeleting ? "..." : "Sí"}
            </button>
            <button className="confirm-no" onClick={() => setShowConfirmation(false)}>
              No
            </button>
          </div>
        ) : (
          <button className="action-button delete" onClick={() => setShowConfirmation(true)} title="Eliminar tarea">
            <Trash size={18} />
          </button>
        )}
      </div>
    </li>
  )
}

export default TaskItem

