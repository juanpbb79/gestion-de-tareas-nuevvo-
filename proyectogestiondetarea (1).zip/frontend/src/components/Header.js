"use client"
import { Link, useNavigate } from "react-router-dom"
import { useAuthContext } from "../context/AuthContext"

/**
 * Componente de encabezado con navegación
 * @component
 */
const Header = () => {
  const { user, isAuthenticated, logout } = useAuthContext()
  const navigate = useNavigate()

  /**
   * Maneja el cierre de sesión
   */
  const handleLogout = () => {
    logout()
    navigate("/login")
  }

  return (
    <header className="app-header">
      <div className="container">
        <div className="header-content">
          <Link to="/" className="logo">
            <h1>TaskManager</h1>
          </Link>

          <nav className="main-nav">
            {isAuthenticated ? (
              <>
                <Link to="/" className="nav-link">
                  Inicio
                </Link>
                <Link to="/profile" className="nav-link">
                  Perfil
                </Link>
                <div className="user-menu">
                  <span className="user-name">Hola, {user.name || "Usuario"}</span>
                  <button onClick={handleLogout} className="logout-button">
                    Cerrar Sesión
                  </button>
                </div>
              </>
            ) : (
              <>
                <Link to="/login" className="nav-link">
                  Iniciar Sesión
                </Link>
                <Link to="/register" className="nav-link register-link">
                  Registrarse
                </Link>
              </>
            )}
          </nav>
        </div>
      </div>
    </header>
  )
}

export default Header

