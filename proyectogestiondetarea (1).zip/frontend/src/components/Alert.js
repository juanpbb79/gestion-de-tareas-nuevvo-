"use client"

import { useState, useEffect } from "react"

/**
 * Componente para mostrar alertas y mensajes
 * @component
 * @param {Object} props - Propiedades del componente
 * @param {string} props.type - Tipo de alerta ('error', 'success', 'warning', 'info')
 * @param {string} props.message - Mensaje a mostrar
 * @param {number} [props.duration=5000] - Duración en milisegundos (0 para no auto-cerrar)
 */
export const Alert = ({ type, message, duration = 5000 }) => {
  const [visible, setVisible] = useState(true)

  // Auto-cerrar después de la duración especificada
  useEffect(() => {
    if (duration > 0) {
      const timer = setTimeout(() => {
        setVisible(false)
      }, duration)

      return () => clearTimeout(timer)
    }
  }, [duration])

  // Si no es visible, no renderizar
  if (!visible) return null

  // Determinar la clase CSS según el tipo
  const alertClass = `alert alert-${type}`

  return (
    <div className={alertClass}>
      <div className="alert-content">
        <p>{message}</p>
      </div>
      <button className="alert-close" onClick={() => setVisible(false)} aria-label="Cerrar">
        &times;
      </button>
    </div>
  )
}

