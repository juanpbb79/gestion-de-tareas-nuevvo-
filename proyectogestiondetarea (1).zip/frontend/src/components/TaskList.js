"use client"

import { useEffect, useState } from "react"
import { useTaskContext } from "../context/TaskContext"
import TaskItem from "./TaskItem"
import { Alert } from "./Alert"
import Spinner from "./Spinner"

/**
 * Componente que muestra la lista de tareas
 * @component
 */
const TaskList = () => {
  // Obtener estado y funciones del contexto
  const { tasks, loading, error, getTasks } = useTaskContext()

  // Estado para filtros
  const [filters, setFilters] = useState({
    status: "todas",
    priority: "todas",
    searchTerm: "",
  })

  // Cargar tareas al montar el componente
  useEffect(() => {
    getTasks()
  }, [])

  /**
   * Maneja cambios en los filtros
   * @param {Event} e - Evento del cambio
   */
  const handleFilterChange = (e) => {
    const { name, value } = e.target
    setFilters({
      ...filters,
      [name]: value,
    })
  }

  /**
   * Filtra las tareas según los criterios seleccionados
   * @returns {Array} - Tareas filtradas
   */
  const getFilteredTasks = () => {
    return tasks.filter((task) => {
      // Filtrar por estado
      if (filters.status !== "todas" && task.status !== filters.status) {
        return false
      }

      // Filtrar por prioridad
      if (filters.priority !== "todas" && task.priority !== filters.priority) {
        return false
      }

      // Filtrar por término de búsqueda
      if (filters.searchTerm && !task.title.toLowerCase().includes(filters.searchTerm.toLowerCase())) {
        return false
      }

      return true
    })
  }

  // Obtener tareas filtradas
  const filteredTasks = getFilteredTasks()

  return (
    <div className="task-list">
      <h2>Mis Tareas</h2>

      {/* Mostrar error si existe */}
      {error && <Alert type="error" message={error} />}

      {/* Filtros */}
      <div className="filters">
        <div className="filter-group">
          <input
            type="text"
            name="searchTerm"
            value={filters.searchTerm}
            onChange={handleFilterChange}
            placeholder="Buscar por título..."
            className="search-input"
          />
        </div>

        <div className="filter-controls">
          <div className="filter-group">
            <label htmlFor="status-filter">Estado:</label>
            <select id="status-filter" name="status" value={filters.status} onChange={handleFilterChange}>
              <option value="todas">Todas</option>
              <option value="pendiente">Pendiente</option>
              <option value="en progreso">En progreso</option>
              <option value="completada">Completada</option>
            </select>
          </div>

          <div className="filter-group">
            <label htmlFor="priority-filter">Prioridad:</label>
            <select id="priority-filter" name="priority" value={filters.priority} onChange={handleFilterChange}>
              <option value="todas">Todas</option>
              <option value="alta">Alta</option>
              <option value="media">Media</option>
              <option value="baja">Baja</option>
            </select>
          </div>
        </div>
      </div>

      {/* Mostrar spinner durante la carga */}
      {loading ? (
        <Spinner />
      ) : filteredTasks.length === 0 ? (
        <div className="no-tasks">
          <p>No hay tareas que coincidan con los filtros seleccionados.</p>
        </div>
      ) : (
        <ul className="tasks-container">
          {filteredTasks.map((task) => (
            <TaskItem key={task._id} task={task} />
          ))}
        </ul>
      )}
    </div>
  )
}

export default TaskList

