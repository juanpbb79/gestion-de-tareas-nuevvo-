/**
 * Componente de pie de página
 * @component
 */
const Footer = () => {
  const currentYear = new Date().getFullYear()

  return (
    <footer className="app-footer">
      <div className="container">
        <div className="footer-content">
          <p className="copyright">&copy; {currentYear} TaskManager - Aplicación de Gestión de Tareas</p>
          <div className="footer-links">
            <a href="/terms" className="footer-link">
              Términos de Uso
            </a>
            <a href="/privacy" className="footer-link">
              Política de Privacidad
            </a>
            <a href="/contact" className="footer-link">
              Contacto
            </a>
          </div>
        </div>
      </div>
    </footer>
  )
}

export default Footer

