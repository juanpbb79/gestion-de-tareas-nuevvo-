/**
 * Componente de spinner para indicar carga
 * @component
 */
const Spinner = () => {
  return (
    <div className="spinner-container">
      <div className="spinner"></div>
      <p>Cargando...</p>
    </div>
  )
}

export default Spinner

