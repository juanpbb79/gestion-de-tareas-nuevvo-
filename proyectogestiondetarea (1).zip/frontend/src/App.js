import { BrowserRouter as Router, Routes, Route, Navigate } from "react-router-dom"
import { AuthProvider } from "./context/AuthContext"
import { TaskProvider } from "./context/TaskContext"
import { useAuthContext } from "./context/AuthContext"

// Componentes
import Header from "./components/Header"
import Footer from "./components/Footer"

// Páginas
import Home from "./pages/Home"
import Login from "./pages/Login"
import Register from "./pages/Register"
import Profile from "./pages/Profile"
import EditTask from "./pages/EditTask"
import NotFound from "./pages/NotFound"

// Estilos
import "./App.css"

/**
 * Componente para rutas protegidas que requieren autenticación
 */
const PrivateRoute = ({ children }) => {
  const { isAuthenticated, loading } = useAuthContext()

  // Si está cargando, mostrar spinner o similar
  if (loading) {
    return <div className="loading-screen">Cargando...</div>
  }

  // Redirigir a login si no está autenticado
  return isAuthenticated ? children : <Navigate to="/login" />
}

/**
 * Componente principal de la aplicación
 */
function App() {
  return (
    <Router>
      <AuthProvider>
        <TaskProvider>
          <div className="App">
            <Header />
            <main className="main-content">
              <Routes>
                {/* Ruta pública - Login */}
                <Route path="/login" element={<Login />} />

                {/* Ruta pública - Registro */}
                <Route path="/register" element={<Register />} />

                {/* Ruta protegida - Inicio */}
                <Route
                  path="/"
                  element={
                    <PrivateRoute>
                      <Home />
                    </PrivateRoute>
                  }
                />

                {/* Ruta protegida - Perfil */}
                <Route
                  path="/profile"
                  element={
                    <PrivateRoute>
                      <Profile />
                    </PrivateRoute>
                  }
                />

                {/* Ruta protegida - Editar tarea */}
                <Route
                  path="/edit-task/:id"
                  element={
                    <PrivateRoute>
                      <EditTask />
                    </PrivateRoute>
                  }
                />

                {/* Ruta para 404 */}
                <Route path="*" element={<NotFound />} />
              </Routes>
            </main>
            <Footer />
          </div>
        </TaskProvider>
      </AuthProvider>
    </Router>
  )
}

export default App

