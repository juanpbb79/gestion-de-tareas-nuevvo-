"use client"

import { createContext, useReducer, useContext } from "react"
import axios from "axios"

// Crear el contexto
const TaskContext = createContext()

// Estado inicial
const initialState = {
  tasks: [],
  loading: false,
  error: null,
  success: false,
  task: null,
}

// Reducer para manejar las acciones
const taskReducer = (state, action) => {
  switch (action.type) {
    case "TASK_REQUEST":
      return { ...state, loading: true, error: null }
    case "TASK_SUCCESS":
      return { ...state, loading: false, success: true }
    case "TASK_ERROR":
      return { ...state, loading: false, error: action.payload }
    case "GET_TASKS":
      return { ...state, loading: false, tasks: action.payload }
    case "GET_TASK":
      return { ...state, loading: false, task: action.payload }
    case "CLEAR_TASK":
      return { ...state, task: null }
    case "CLEAR_ERROR":
      return { ...state, error: null }
    default:
      return state
  }
}

// Proveedor del contexto
export const TaskProvider = ({ children }) => {
  const [state, dispatch] = useReducer(taskReducer, initialState)

  // Obtener todas las tareas
  const getTasks = async () => {
    try {
      dispatch({ type: "TASK_REQUEST" })

      // Obtener token del almacenamiento local
      const token = localStorage.getItem("token")

      // Configurar headers con token de autenticación
      const config = {
        headers: {
          Authorization: token ? `Bearer ${token}` : "",
        },
      }

      const response = await axios.get("http://localhost:5000/api/tasks", config)

      dispatch({
        type: "GET_TASKS",
        payload: response.data.data || response.data, // Compatibilidad con ambos formatos
      })
    } catch (error) {
      dispatch({
        type: "TASK_ERROR",
        payload: error.response?.data?.message || "Error al obtener las tareas",
      })
    }
  }

  // Crear una nueva tarea
  const createTask = async (taskData) => {
    try {
      dispatch({ type: "TASK_REQUEST" })

      // Obtener token del almacenamiento local
      const token = localStorage.getItem("token")

      // Configurar headers con token de autenticación
      const config = {
        headers: {
          "Content-Type": "application/json",
          Authorization: token ? `Bearer ${token}` : "",
        },
      }

      await axios.post("http://localhost:5000/api/tasks", taskData, config)

      dispatch({ type: "TASK_SUCCESS" })

      // Actualizar la lista de tareas
      getTasks()
    } catch (error) {
      dispatch({
        type: "TASK_ERROR",
        payload: error.response?.data?.message || "Error al crear la tarea",
      })
    }
  }

  // Actualizar una tarea existente
  const updateTask = async (id, taskData) => {
    try {
      dispatch({ type: "TASK_REQUEST" })

      // Obtener token del almacenamiento local
      const token = localStorage.getItem("token")

      // Configurar headers con token de autenticación
      const config = {
        headers: {
          "Content-Type": "application/json",
          Authorization: token ? `Bearer ${token}` : "",
        },
      }

      await axios.put(`http://localhost:5000/api/tasks/${id}`, taskData, config)

      dispatch({ type: "TASK_SUCCESS" })

      // Actualizar la lista de tareas
      getTasks()
    } catch (error) {
      dispatch({
        type: "TASK_ERROR",
        payload: error.response?.data?.message || "Error al actualizar la tarea",
      })
    }
  }

  // Eliminar una tarea
  const deleteTask = async (id) => {
    try {
      dispatch({ type: "TASK_REQUEST" })

      // Obtener token del almacenamiento local
      const token = localStorage.getItem("token")

      // Configurar headers con token de autenticación
      const config = {
        headers: {
          Authorization: token ? `Bearer ${token}` : "",
        },
      }

      await axios.delete(`http://localhost:5000/api/tasks/${id}`, config)

      dispatch({ type: "TASK_SUCCESS" })

      // Actualizar la lista de tareas
      getTasks()
    } catch (error) {
      dispatch({
        type: "TASK_ERROR",
        payload: error.response?.data?.message || "Error al eliminar la tarea",
      })
    }
  }

  // Limpiar errores
  const clearError = () => {
    dispatch({ type: "CLEAR_ERROR" })
  }

  return (
    <TaskContext.Provider
      value={{
        tasks: state.tasks,
        loading: state.loading,
        error: state.error,
        success: state.success,
        task: state.task,
        getTasks,
        createTask,
        updateTask,
        deleteTask,
        clearError,
      }}
    >
      {children}
    </TaskContext.Provider>
  )
}

// Hook personalizado para usar el contexto
export const useTaskContext = () => {
  return useContext(TaskContext)
}

