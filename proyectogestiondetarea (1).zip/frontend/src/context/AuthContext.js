"use client"

import { createContext, useReducer, useContext } from "react"
import axios from "axios"

// Crear el contexto
const AuthContext = createContext()

// Estado inicial
const initialState = {
  user: null,
  isAuthenticated: false,
  loading: false,
  error: null,
}

// Cargar usuario del localStorage si existe
const userFromStorage = localStorage.getItem("user") ? JSON.parse(localStorage.getItem("user")) : null

if (userFromStorage) {
  initialState.user = userFromStorage
  initialState.isAuthenticated = true
}

// Reducer para manejar las acciones
const authReducer = (state, action) => {
  switch (action.type) {
    case "AUTH_REQUEST":
      return { ...state, loading: true, error: null }
    case "AUTH_SUCCESS":
      return {
        ...state,
        loading: false,
        isAuthenticated: true,
        user: action.payload,
      }
    case "AUTH_FAIL":
      return {
        ...state,
        loading: false,
        isAuthenticated: false,
        user: null,
        error: action.payload,
      }
    case "LOGOUT":
      return {
        ...state,
        isAuthenticated: false,
        user: null,
      }
    case "CLEAR_ERROR":
      return { ...state, error: null }
    default:
      return state
  }
}

// Proveedor del contexto
export const AuthProvider = ({ children }) => {
  const [state, dispatch] = useReducer(authReducer, initialState)

  // Registrar un nuevo usuario
  const register = async (userData) => {
    try {
      dispatch({ type: "AUTH_REQUEST" })

      const config = {
        headers: {
          "Content-Type": "application/json",
        },
      }

      const response = await axios.post("http://localhost:5000/api/auth/register", userData, config)

      dispatch({
        type: "AUTH_SUCCESS",
        payload: response.data.data || response.data,
      })

      // Guardar datos en localStorage
      localStorage.setItem("user", JSON.stringify(response.data.data || response.data))
      localStorage.setItem("token", response.data.token || response.data.data.token)
    } catch (error) {
      dispatch({
        type: "AUTH_FAIL",
        payload: error.response?.data?.message || "Error en el registro",
      })
    }
  }

  // Iniciar sesión
  const login = async (email, password) => {
    try {
      dispatch({ type: "AUTH_REQUEST" })

      const config = {
        headers: {
          "Content-Type": "application/json",
        },
      }

      const response = await axios.post("http://localhost:5000/api/auth/login", { email, password }, config)

      dispatch({
        type: "AUTH_SUCCESS",
        payload: response.data.data || response.data,
      })

      // Guardar datos en localStorage
      localStorage.setItem("user", JSON.stringify(response.data.data || response.data))
      localStorage.setItem("token", response.data.token || response.data.data.token)
    } catch (error) {
      dispatch({
        type: "AUTH_FAIL",
        payload: error.response?.data?.message || "Credenciales inválidas",
      })
    }
  }

  // Cerrar sesión
  const logout = () => {
    localStorage.removeItem("user")
    localStorage.removeItem("token")
    dispatch({ type: "LOGOUT" })
  }

  // Limpiar errores
  const clearError = () => {
    dispatch({ type: "CLEAR_ERROR" })
  }

  return (
    <AuthContext.Provider
      value={{
        user: state.user,
        isAuthenticated: state.isAuthenticated,
        loading: state.loading,
        error: state.error,
        register,
        login,
        logout,
        clearError,
      }}
    >
      {children}
    </AuthContext.Provider>
  )
}

// Hook personalizado para usar el contexto
export const useAuthContext = () => {
  return useContext(AuthContext)
}

