"use client"

import { useState, useEffect } from "react"
import { Link, useNavigate } from "react-router-dom"
import { useAuthContext } from "../context/AuthContext"
import { Alert } from "../components/Alert"

/**
 * Página de inicio de sesión
 * @component
 */
const Login = () => {
  const [formData, setFormData] = useState({
    email: "",
    password: "",
  })

  const { login, error, loading, isAuthenticated, clearError } = useAuthContext()
  const navigate = useNavigate()

  // Redirigir si ya está autenticado
  useEffect(() => {
    if (isAuthenticated) {
      navigate("/")
    }
  }, [isAuthenticated, navigate])

  // Limpiar errores al montar el componente
  useEffect(() => {
    clearError()
  }, [clearError])

  /**
   * Maneja cambios en los campos del formulario
   * @param {Event} e - Evento del cambio
   */
  const handleChange = (e) => {
    const { name, value } = e.target
    setFormData({
      ...formData,
      [name]: value,
    })
  }

  /**
   * Maneja el envío del formulario
   * @param {Event} e - Evento del formulario
   */
  const handleSubmit = async (e) => {
    e.preventDefault()
    await login(formData.email, formData.password)
  }

  return (
    <div className="container">
      <div className="form-container">
        <h2 className="form-title">Iniciar Sesión</h2>

        {error && <Alert type="error" message={error} />}

        <form onSubmit={handleSubmit}>
          <div className="form-group">
            <label htmlFor="email">Correo Electrónico</label>
            <input
              type="email"
              id="email"
              name="email"
              value={formData.email}
              onChange={handleChange}
              placeholder="tu@email.com"
              required
            />
          </div>

          <div className="form-group">
            <label htmlFor="password">Contraseña</label>
            <input
              type="password"
              id="password"
              name="password"
              value={formData.password}
              onChange={handleChange}
              placeholder="Tu contraseña"
              required
            />
          </div>

          <button type="submit" disabled={loading} className={loading ? "button-loading" : ""}>
            {loading ? "Iniciando sesión..." : "Iniciar Sesión"}
          </button>
        </form>

        <div className="form-footer">
          <p>
            ¿No tienes una cuenta? <Link to="/register">Regístrate aquí</Link>
          </p>
        </div>
      </div>
    </div>
  )
}

export default Login

