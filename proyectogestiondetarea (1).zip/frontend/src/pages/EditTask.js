"use client"

import { useEffect, useState } from "react"
import { useParams, useNavigate } from "react-router-dom"
import { useTaskContext } from "../context/TaskContext"
import TaskForm from "../components/TaskForm"
import { Alert } from "../components/Alert"
import Spinner from "../components/Spinner"

/**
 * Página para editar una tarea existente
 * @component
 */
const EditTask = () => {
  const { id } = useParams()
  const navigate = useNavigate()
  const { tasks, getTasks, loading, error } = useTaskContext()
  const [task, setTask] = useState(null)
  const [notFound, setNotFound] = useState(false)

  // Cargar tareas si no están cargadas
  useEffect(() => {
    if (tasks.length === 0) {
      getTasks()
    }
  }, [getTasks, tasks.length])

  // Buscar la tarea específica
  useEffect(() => {
    if (tasks.length > 0) {
      const foundTask = tasks.find((t) => t._id === id)
      if (foundTask) {
        setTask(foundTask)
      } else {
        setNotFound(true)
      }
    }
  }, [tasks, id])

  // Manejar botón de volver
  const handleGoBack = () => {
    navigate("/")
  }

  // Mostrar spinner durante la carga
  if (loading) {
    return (
      <div className="container">
        <Spinner />
      </div>
    )
  }

  // Mostrar mensaje si la tarea no existe
  if (notFound) {
    return (
      <div className="container">
        <div className="not-found-message">
          <h2>Tarea no encontrada</h2>
          <p>La tarea que intentas editar no existe o ha sido eliminada.</p>
          <button onClick={handleGoBack} className="go-back-button">
            Volver a la lista de tareas
          </button>
        </div>
      </div>
    )
  }

  return (
    <div className="container">
      <div className="page-header">
        <h1>Editar Tarea</h1>
        <button onClick={handleGoBack} className="secondary-button">
          Volver a la lista
        </button>
      </div>

      {error && <Alert type="error" message={error} />}

      {task ? (
        <TaskForm taskToEdit={task} />
      ) : (
        <div className="loading-message">
          <p>Cargando información de la tarea...</p>
        </div>
      )}
    </div>
  )
}

export default EditTask

