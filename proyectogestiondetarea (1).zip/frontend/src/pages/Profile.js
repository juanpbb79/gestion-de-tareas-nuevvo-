"use client"

import { useState } from "react"
import { useAuthContext } from "../context/AuthContext"
import { Alert } from "../components/Alert"

/**
 * Página de perfil de usuario
 * @component
 */
const Profile = () => {
  const { user, loading } = useAuthContext()
  const [successMessage, setSuccessMessage] = useState("")

  // Simulación de actualización de perfil
  const handleUpdateProfile = (e) => {
    e.preventDefault()
    // Aquí iría la lógica real de actualización
    setSuccessMessage("Perfil actualizado correctamente")

    // Limpiar mensaje después de 5 segundos
    setTimeout(() => {
      setSuccessMessage("")
    }, 5000)
  }

  if (loading) {
    return <div className="container">Cargando información del perfil...</div>
  }

  return (
    <div className="container">
      <div className="page-header">
        <h1>Mi Perfil</h1>
      </div>

      {successMessage && <Alert type="success" message={successMessage} />}

      <div className="profile-container">
        <div className="profile-info">
          <div className="profile-avatar">{user?.name?.charAt(0) || "U"}</div>

          <div className="profile-details">
            <h2>{user?.name}</h2>
            <p>{user?.email}</p>
            <p>Miembro desde: {new Date(user?.createdAt || Date.now()).toLocaleDateString()}</p>
          </div>
        </div>

        <div className="profile-stats">
          <div className="stat-card">
            <h3>Tareas Pendientes</h3>
            <p className="stat-number">12</p>
          </div>

          <div className="stat-card">
            <h3>Tareas Completadas</h3>
            <p className="stat-number">24</p>
          </div>

          <div className="stat-card">
            <h3>Total de Tareas</h3>
            <p className="stat-number">36</p>
          </div>
        </div>

        <div className="profile-form">
          <h3>Actualizar Información</h3>

          <form onSubmit={handleUpdateProfile}>
            <div className="form-group">
              <label htmlFor="name">Nombre</label>
              <input type="text" id="name" name="name" defaultValue={user?.name} />
            </div>

            <div className="form-group">
              <label htmlFor="email">Correo Electrónico</label>
              <input type="email" id="email" name="email" defaultValue={user?.email} disabled />
              <small>El correo electrónico no se puede cambiar</small>
            </div>

            <div className="form-group">
              <label htmlFor="password">Nueva Contraseña</label>
              <input
                type="password"
                id="password"
                name="password"
                placeholder="Dejar en blanco para mantener la actual"
              />
            </div>

            <button type="submit">Actualizar Perfil</button>
          </form>
        </div>
      </div>
    </div>
  )
}

export default Profile

