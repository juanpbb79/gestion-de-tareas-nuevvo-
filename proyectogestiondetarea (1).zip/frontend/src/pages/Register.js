"use client"

import { useState, useEffect } from "react"
import { Link, useNavigate } from "react-router-dom"
import { useAuthContext } from "../context/AuthContext"
import { Alert } from "../components/Alert"

/**
 * Página de registro de usuarios
 * @component
 */
const Register = () => {
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    password: "",
    confirmPassword: "",
  })

  const [passwordError, setPasswordError] = useState("")
  const { register, error, loading, isAuthenticated, clearError } = useAuthContext()
  const navigate = useNavigate()

  // Redirigir si ya está autenticado
  useEffect(() => {
    if (isAuthenticated) {
      navigate("/")
    }
  }, [isAuthenticated, navigate])

  // Limpiar errores al montar el componente
  useEffect(() => {
    clearError()
  }, [clearError])

  /**
   * Maneja cambios en los campos del formulario
   * @param {Event} e - Evento del cambio
   */
  const handleChange = (e) => {
    const { name, value } = e.target
    setFormData({
      ...formData,
      [name]: value,
    })

    // Validar coincidencia de contraseñas
    if (name === "confirmPassword" || name === "password") {
      if (name === "password" && formData.confirmPassword && value !== formData.confirmPassword) {
        setPasswordError("Las contraseñas no coinciden")
      } else if (name === "confirmPassword" && value !== formData.password) {
        setPasswordError("Las contraseñas no coinciden")
      } else {
        setPasswordError("")
      }
    }
  }

  /**
   * Maneja el envío del formulario
   * @param {Event} e - Evento del formulario
   */
  const handleSubmit = async (e) => {
    e.preventDefault()

    // Validar que las contraseñas coincidan
    if (formData.password !== formData.confirmPassword) {
      setPasswordError("Las contraseñas no coinciden")
      return
    }

    // Validar longitud de contraseña
    if (formData.password.length < 6) {
      setPasswordError("La contraseña debe tener al menos 6 caracteres")
      return
    }

    // Enviar datos de registro
    await register({
      name: formData.name,
      email: formData.email,
      password: formData.password,
    })
  }

  return (
    <div className="container">
      <div className="form-container">
        <h2 className="form-title">Crear Cuenta</h2>

        {error && <Alert type="error" message={error} />}

        <form onSubmit={handleSubmit}>
          <div className="form-group">
            <label htmlFor="name">Nombre Completo</label>
            <input
              type="text"
              id="name"
              name="name"
              value={formData.name}
              onChange={handleChange}
              placeholder="Tu nombre"
              required
            />
          </div>

          <div className="form-group">
            <label htmlFor="email">Correo Electrónico</label>
            <input
              type="email"
              id="email"
              name="email"
              value={formData.email}
              onChange={handleChange}
              placeholder="tu@email.com"
              required
            />
          </div>

          <div className="form-group">
            <label htmlFor="password">Contraseña</label>
            <input
              type="password"
              id="password"
              name="password"
              value={formData.password}
              onChange={handleChange}
              placeholder="Mínimo 6 caracteres"
              required
            />
          </div>

          <div className="form-group">
            <label htmlFor="confirmPassword">Confirmar Contraseña</label>
            <input
              type="password"
              id="confirmPassword"
              name="confirmPassword"
              value={formData.confirmPassword}
              onChange={handleChange}
              placeholder="Repite tu contraseña"
              required
            />
            {passwordError && <p className="error-text">{passwordError}</p>}
          </div>

          <button type="submit" disabled={loading || passwordError} className={loading ? "button-loading" : ""}>
            {loading ? "Registrando..." : "Crear Cuenta"}
          </button>
        </form>

        <div className="form-footer">
          <p>
            ¿Ya tienes una cuenta? <Link to="/login">Inicia sesión aquí</Link>
          </p>
        </div>
      </div>
    </div>
  )
}

export default Register

