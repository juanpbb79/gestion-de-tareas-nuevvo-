import { Link } from "react-router-dom"

/**
 * Página 404 - No encontrado
 * @component
 */
const NotFound = () => {
  return (
    <div className="container">
      <div className="not-found-container">
        <h1 className="not-found-title">404</h1>
        <h2>Página no encontrada</h2>
        <p>Lo sentimos, la página que estás buscando no existe o ha sido movida.</p>
        <Link to="/" className="home-link">
          Volver a la página principal
        </Link>
      </div>
    </div>
  )
}

export default NotFound

