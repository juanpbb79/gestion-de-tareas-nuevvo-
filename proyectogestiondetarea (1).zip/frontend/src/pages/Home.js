import TaskForm from "../components/TaskForm"
import TaskList from "../components/TaskList"
import { useAuthContext } from "../context/AuthContext"

/**
 * Página principal que muestra el formulario de creación y la lista de tareas
 * @component
 */
const Home = () => {
  const { user } = useAuthContext()

  return (
    <div className="container">
      <div className="page-header">
        <h1>Gestión de Tareas</h1>
        <p className="welcome-message">
          Bienvenido, {user?.name || "Usuario"}. Organiza tus tareas de manera eficiente.
        </p>
      </div>

      <div className="home-content">
        <TaskForm />
        <TaskList />
      </div>
    </div>
  )
}

export default Home

