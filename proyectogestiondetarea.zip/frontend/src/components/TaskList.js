"use client"

import { useState } from "react"
import axios from "axios"
import { CheckCircle, XCircle, Trash2, AlertCircle } from "lucide-react"

const TaskList = ({ tasks, fetchTasks }) => {
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState("")
  const [taskToDelete, setTaskToDelete] = useState(null)
  const [showConfirmation, setShowConfirmation] = useState(false)

  // Función para cambiar el estado de una tarea
  const toggleTaskStatus = async (taskId, currentStatus) => {
    setLoading(true)
    setError("")

    try {
      const newStatus = currentStatus === "pendiente" ? "completada" : "pendiente"
      await axios.put(`http://localhost:5000/api/tasks/${taskId}`, { status: newStatus })
      fetchTasks() // Actualizar la lista de tareas
    } catch (error) {
      setError("Error al actualizar el estado de la tarea")
      console.error("Error al actualizar la tarea:", error)
    } finally {
      setLoading(false)
    }
  }

  // Función para mostrar el diálogo de confirmación
  const confirmDelete = (taskId) => {
    setTaskToDelete(taskId)
    setShowConfirmation(true)
  }

  // Función para eliminar una tarea
  const deleteTask = async () => {
    if (!taskToDelete) return

    setLoading(true)
    setError("")

    try {
      await axios.delete(`http://localhost:5000/api/tasks/${taskToDelete}`)
      fetchTasks() // Actualizar la lista de tareas
      setShowConfirmation(false)
      setTaskToDelete(null)
    } catch (error) {
      setError("Error al eliminar la tarea")
      console.error("Error al eliminar la tarea:", error)
    } finally {
      setLoading(false)
    }
  }

  // Función para formatear la fecha
  const formatDate = (dateString) => {
    const options = { year: "numeric", month: "long", day: "numeric" }
    return new Date(dateString).toLocaleDateString("es-ES", options)
  }

  // Función para obtener el color de prioridad
  const getPriorityColor = (priority) => {
    switch (priority) {
      case "alta":
        return "priority-high"
      case "media":
        return "priority-medium"
      case "baja":
        return "priority-low"
      default:
        return ""
    }
  }

  return (
    <div className="task-list">
      <h2>Mis Tareas</h2>

      {error && (
        <div className="error-message">
          <AlertCircle size={18} />
          <span>{error}</span>
        </div>
      )}

      {loading && <div className="loading-spinner">Cargando...</div>}

      {tasks.length === 0 ? (
        <div className="empty-list">
          <p>No tienes tareas pendientes. ¡Crea una nueva tarea!</p>
        </div>
      ) : (
        <ul>
          {tasks.map((task) => (
            <li key={task._id} className={`task-item ${task.status} ${getPriorityColor(task.priority)}`}>
              <div className="task-content">
                <h3>{task.title}</h3>
                <p className="task-description">{task.description}</p>
                <div className="task-details">
                  <span className="task-date">
                    <strong>Fecha:</strong> {formatDate(task.dueDate)}
                  </span>
                  <span className={`task-priority ${getPriorityColor(task.priority)}`}>
                    <strong>Prioridad:</strong> {task.priority}
                  </span>
                  <span className={`task-status status-${task.status}`}>
                    <strong>Estado:</strong> {task.status}
                  </span>
                </div>
              </div>
              <div className="task-actions">
                <button
                  onClick={() => toggleTaskStatus(task._id, task.status)}
                  className="action-btn status-btn"
                  title={task.status === "pendiente" ? "Marcar como completada" : "Marcar como pendiente"}
                >
                  {task.status === "pendiente" ? <CheckCircle size={20} /> : <XCircle size={20} />}
                </button>
                <button
                  onClick={() => confirmDelete(task._id)}
                  className="action-btn delete-btn"
                  title="Eliminar tarea"
                >
                  <Trash2 size={20} />
                </button>
              </div>
            </li>
          ))}
        </ul>
      )}

      {/* Modal de confirmación para eliminar */}
      {showConfirmation && (
        <div className="confirmation-modal">
          <div className="modal-content">
            <h3>Confirmar eliminación</h3>
            <p>¿Estás seguro de que deseas eliminar esta tarea?</p>
            <div className="modal-actions">
              <button onClick={() => setShowConfirmation(false)} className="cancel-btn" disabled={loading}>
                Cancelar
              </button>
              <button onClick={deleteTask} className="confirm-btn" disabled={loading}>
                {loading ? "Eliminando..." : "Eliminar"}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}

export default TaskList

