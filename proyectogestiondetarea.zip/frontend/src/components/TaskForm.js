"use client"

import { useState } from "react"
import axios from "axios"
import { AlertCircle } from "lucide-react"

const TaskForm = ({ fetchTasks }) => {
  const [formData, setFormData] = useState({
    title: "",
    description: "",
    dueDate: "",
    priority: "media",
  })
  const [errors, setErrors] = useState({})
  const [loading, setLoading] = useState(false)
  const [success, setSuccess] = useState(false)
  const [apiError, setApiError] = useState("")

  // Manejar cambios en los inputs
  const handleChange = (e) => {
    const { name, value } = e.target
    setFormData({
      ...formData,
      [name]: value,
    })

    // Limpiar errores al editar
    if (errors[name]) {
      setErrors({
        ...errors,
        [name]: "",
      })
    }
  }

  // Validar el formulario
  const validateForm = () => {
    const newErrors = {}

    if (!formData.title.trim()) {
      newErrors.title = "El título es obligatorio"
    }

    if (!formData.description.trim()) {
      newErrors.description = "La descripción es obligatoria"
    }

    if (!formData.dueDate) {
      newErrors.dueDate = "La fecha de vencimiento es obligatoria"
    } else {
      const selectedDate = new Date(formData.dueDate)
      const today = new Date()
      today.setHours(0, 0, 0, 0)

      if (selectedDate < today) {
        newErrors.dueDate = "La fecha no puede ser anterior a hoy"
      }
    }

    setErrors(newErrors)
    return Object.keys(newErrors).length === 0
  }

  // Manejar envío del formulario
  const handleSubmit = async (e) => {
    e.preventDefault()

    // Validar formulario
    if (!validateForm()) {
      return
    }

    setLoading(true)
    setApiError("")

    try {
      await axios.post("http://localhost:5000/api/tasks", formData)

      // Mostrar mensaje de éxito
      setSuccess(true)
      setTimeout(() => setSuccess(false), 3000)

      // Limpiar formulario
      setFormData({
        title: "",
        description: "",
        dueDate: "",
        priority: "media",
      })

      // Actualizar lista de tareas
      fetchTasks()
    } catch (error) {
      setApiError(error.response?.data?.message || "Error al crear la tarea. Por favor, intenta de nuevo.")
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="task-form">
      <h2>Crear Nueva Tarea</h2>

      {apiError && (
        <div className="error-message">
          <AlertCircle size={18} />
          <span>{apiError}</span>
        </div>
      )}

      {success && <div className="success-message">¡Tarea creada exitosamente!</div>}

      <form onSubmit={handleSubmit}>
        <div className="form-group">
          <label htmlFor="title">Título</label>
          <input
            type="text"
            id="title"
            name="title"
            value={formData.title}
            onChange={handleChange}
            className={errors.title ? "input-error" : ""}
            disabled={loading}
          />
          {errors.title && <span className="error-text">{errors.title}</span>}
        </div>

        <div className="form-group">
          <label htmlFor="description">Descripción</label>
          <textarea
            id="description"
            name="description"
            value={formData.description}
            onChange={handleChange}
            className={errors.description ? "input-error" : ""}
            disabled={loading}
          />
          {errors.description && <span className="error-text">{errors.description}</span>}
        </div>

        <div className="form-group">
          <label htmlFor="dueDate">Fecha de Vencimiento</label>
          <input
            type="date"
            id="dueDate"
            name="dueDate"
            value={formData.dueDate}
            onChange={handleChange}
            className={errors.dueDate ? "input-error" : ""}
            disabled={loading}
          />
          {errors.dueDate && <span className="error-text">{errors.dueDate}</span>}
        </div>

        <div className="form-group">
          <label htmlFor="priority">Prioridad</label>
          <select id="priority" name="priority" value={formData.priority} onChange={handleChange} disabled={loading}>
            <option value="alta">Alta</option>
            <option value="media">Media</option>
            <option value="baja">Baja</option>
          </select>
        </div>

        <button type="submit" className="submit-btn" disabled={loading}>
          {loading ? "Creando..." : "Crear Tarea"}
        </button>
      </form>
    </div>
  )
}

export default TaskForm

