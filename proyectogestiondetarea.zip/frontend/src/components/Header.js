"use client"
import { Link } from "react-router-dom"

const Header = ({ isAuthenticated, logout }) => {
  return (
    <header>
      <h1>Gestión de Tareas</h1>
      <nav>
        {isAuthenticated ? (
          <>
            <Link to="/">Inicio</Link>
            <button onClick={logout} className="logout-btn">
              Cerrar Sesión
            </button>
          </>
        ) : (
          <>
            <Link to="/login">Iniciar Sesión</Link>
            <Link to="/register">Registrarse</Link>
          </>
        )}
      </nav>
    </header>
  )
}

export default Header

