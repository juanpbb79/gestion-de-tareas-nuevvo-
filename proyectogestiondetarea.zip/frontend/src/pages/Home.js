"use client"

import { useState, useEffect } from "react"
import axios from "axios"
import TaskForm from "../components/TaskForm"
import TaskList from "../components/TaskList"
import { AlertCircle } from "lucide-react"

const Home = () => {
  const [tasks, setTasks] = useState([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState("")
  const [filter, setFilter] = useState("todas") // todas, pendientes, completadas

  // Obtener tareas al cargar la página
  useEffect(() => {
    fetchTasks()
  }, [])

  // Función para obtener las tareas
  const fetchTasks = async () => {
    setLoading(true)
    setError("")

    try {
      const response = await axios.get("http://localhost:5000/api/tasks")
      setTasks(response.data)
    } catch (error) {
      setError("Error al cargar las tareas. Por favor, intenta de nuevo.")
      console.error("Error al obtener las tareas:", error)
    } finally {
      setLoading(false)
    }
  }

  // Filtrar tareas según el estado seleccionado
  const filteredTasks = tasks.filter((task) => {
    if (filter === "todas") return true
    if (filter === "pendientes") return task.status === "pendiente"
    if (filter === "completadas") return task.status === "completada"
    return true
  })

  // Ordenar tareas por prioridad y fecha
  const sortedTasks = [...filteredTasks].sort((a, b) => {
    // Primero por estado (pendientes primero)
    if (a.status === "pendiente" && b.status === "completada") return -1
    if (a.status === "completada" && b.status === "pendiente") return 1

    // Luego por prioridad
    const priorityOrder = { alta: 1, media: 2, baja: 3 }
    if (priorityOrder[a.priority] !== priorityOrder[b.priority]) {
      return priorityOrder[a.priority] - priorityOrder[b.priority]
    }

    // Finalmente por fecha de vencimiento
    return new Date(a.dueDate) - new Date(b.dueDate)
  })

  return (
    <div className="home-container">
      {error && (
        <div className="error-message global-error">
          <AlertCircle size={18} />
          <span>{error}</span>
        </div>
      )}

      <div className="dashboard">
        <div className="stats">
          <div className="stat-card">
            <h3>Total de Tareas</h3>
            <p className="stat-number">{tasks.length}</p>
          </div>
          <div className="stat-card">
            <h3>Pendientes</h3>
            <p className="stat-number">{tasks.filter((task) => task.status === "pendiente").length}</p>
          </div>
          <div className="stat-card">
            <h3>Completadas</h3>
            <p className="stat-number">{tasks.filter((task) => task.status === "completada").length}</p>
          </div>
        </div>

        <TaskForm fetchTasks={fetchTasks} />

        <div className="filter-controls">
          <h3>Filtrar por estado:</h3>
          <div className="filter-buttons">
            <button className={`filter-btn ${filter === "todas" ? "active" : ""}`} onClick={() => setFilter("todas")}>
              Todas
            </button>
            <button
              className={`filter-btn ${filter === "pendientes" ? "active" : ""}`}
              onClick={() => setFilter("pendientes")}
            >
              Pendientes
            </button>
            <button
              className={`filter-btn ${filter === "completadas" ? "active" : ""}`}
              onClick={() => setFilter("completadas")}
            >
              Completadas
            </button>
          </div>
        </div>

        <TaskList tasks={sortedTasks} fetchTasks={fetchTasks} />
      </div>
    </div>
  )
}

export default Home

