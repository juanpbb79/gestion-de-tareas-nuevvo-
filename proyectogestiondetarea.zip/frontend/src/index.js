import React from "react"
import { createRoot } from "react-dom/client"
import App from "./App"
import "./index.css"
import "./App.css"
import axios from "axios"

// Configuración global de axios
axios.defaults.baseURL = "http://localhost:5000"

// Interceptor para manejar errores
axios.interceptors.response.use(
  (response) => response,
  (error) => {
    // Si el token es inválido, redirigir al login
    if (error.response && error.response.status === 401) {
      localStorage.removeItem("token")
      window.location.href = "/login"
    }
    return Promise.reject(error)
  },
)

// Configurar el token si existe en localStorage
const token = localStorage.getItem("token")
if (token) {
  axios.defaults.headers.common["Authorization"] = `Bearer ${token}`
}

// Crear la raíz para la aplicación
const container = document.getElementById("root")
const root = createRoot(container)

// Renderizar la aplicación
root.render(
  <React.StrictMode>
    <App />
  </React.StrictMode>,
)

