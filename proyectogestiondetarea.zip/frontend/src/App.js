"use client"

import { useState, useEffect } from "react"
import { BrowserRouter as Router, Routes, Route, Navigate } from "react-router-dom"
import axios from "axios"
import "./App.css"

// Importamos los componentes de páginas
import Login from "./pages/Login"
import Register from "./pages/Register"
import Home from "./pages/Home"
import Header from "./components/Header"

function App() {
  const [isAuthenticated, setIsAuthenticated] = useState(false)
  const [user, setUser] = useState(null)
  const [loading, setLoading] = useState(true)

  // Verificar si el usuario está autenticado al cargar la aplicación
  useEffect(() => {
    const checkAuth = async () => {
      const token = localStorage.getItem("token")
      if (token) {
        try {
          // Configurar el token en los headers por defecto
          axios.defaults.headers.common["Authorization"] = `Bearer ${token}`
          setIsAuthenticated(true)
          // Aquí podrías hacer una petición para obtener los datos del usuario
          // const response = await axios.get("http://localhost:5000/api/users/profile");
          // setUser(response.data);
        } catch (error) {
          console.error("Error al verificar autenticación:", error)
          localStorage.removeItem("token")
        }
      }
      setLoading(false)
    }

    checkAuth()
  }, [])

  // Función para manejar el login
  const login = (token, userData) => {
    localStorage.setItem("token", token)
    axios.defaults.headers.common["Authorization"] = `Bearer ${token}`
    setIsAuthenticated(true)
    setUser(userData)
  }

  // Función para manejar el logout
  const logout = () => {
    localStorage.removeItem("token")
    delete axios.defaults.headers.common["Authorization"]
    setIsAuthenticated(false)
    setUser(null)
  }

  if (loading) {
    return <div className="loading">Cargando...</div>
  }

  return (
    <Router>
      <div className="App">
        <Header isAuthenticated={isAuthenticated} logout={logout} />
        <main>
          <Routes>
            <Route path="/" element={isAuthenticated ? <Home /> : <Navigate to="/login" />} />
            <Route path="/login" element={!isAuthenticated ? <Login login={login} /> : <Navigate to="/" />} />
            <Route path="/register" element={!isAuthenticated ? <Register /> : <Navigate to="/" />} />
          </Routes>
        </main>
        <footer>
          <p>&copy; 2023 Gestión de Tareas</p>
        </footer>
      </div>
    </Router>
  )
}

export default App

