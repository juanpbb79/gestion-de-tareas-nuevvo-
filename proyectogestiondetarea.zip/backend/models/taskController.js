const Task = require("../models/Task")

// Crear una tarea
const createTask = async (req, res) => {
  const { title, description, dueDate, priority } = req.body

  try {
    const task = await Task.create({
      user: req.user._id,
      title,
      description,
      dueDate,
      priority,
    })
    res.status(201).json(task)
  } catch (error) {
    res.status(500).json({ message: "Error al crear la tarea" })
  }
}

// Obtener todas las tareas del usuario
const getTasks = async (req, res) => {
  try {
    const tasks = await Task.find({ user: req.user._id })
    res.status(200).json(tasks)
  } catch (error) {
    res.status(500).json({ message: "Error al obtener las tareas" })
  }
}

// Actualizar una tarea
const updateTask = async (req, res) => {
  const { title, description, dueDate, priority, status } = req.body

  try {
    const task = await Task.findById(req.params.id)
    if (task) {
      task.title = title || task.title
      task.description = description || task.description
      task.dueDate = dueDate || task.dueDate
      task.priority = priority || task.priority
      task.status = status || task.status

      const updatedTask = await task.save()
      res.status(200).json(updatedTask)
    } else {
      res.status(404).json({ message: "Tarea no encontrada" })
    }
  } catch (error) {
    res.status(500).json({ message: "Error al actualizar la tarea" })
  }
}

// Eliminar una tarea
const deleteTask = async (req, res) => {
  try {
    const task = await Task.findById(req.params.id)
    if (task) {
      await task.remove()
      res.status(200).json({ message: "Tarea eliminada" })
    } else {
      res.status(404).json({ message: "Tarea no encontrada" })
    }
  } catch (error) {
    res.status(500).json({ message: "Error al eliminar la tarea" })
  }
}

module.exports = { createTask, getTasks, updateTask, deleteTask }

