const Task = require("../models/Task")

// Crear una tarea
const createTask = async (req, res) => {
  try {
    const task = await Task.create(req.body)
    res.status(201).json(task)
  } catch (error) {
    res.status(500).json({ message: "Error al crear la tarea" })
  }
}

// Obtener todas las tareas
const getTasks = async (req, res) => {
  try {
    const tasks = await Task.find()
    res.status(200).json(tasks)
  } catch (error) {
    res.status(500).json({ message: "Error al obtener las tareas" })
  }
}

// Actualizar una tarea
const updateTask = async (req, res) => {
  try {
    const task = await Task.findByIdAndUpdate(req.params.id, req.body, { new: true })
    res.status(200).json(task)
  } catch (error) {
    res.status(500).json({ message: "Error al actualizar la tarea" })
  }
}

// Eliminar una tarea
const deleteTask = async (req, res) => {
  try {
    await Task.findByIdAndDelete(req.params.id)
    res.status(200).json({ message: "Tarea eliminada" })
  } catch (error) {
    res.status(500).json({ message: "Error al eliminar la tarea" })
  }
}

module.exports = { createTask, getTasks, updateTask, deleteTask }

