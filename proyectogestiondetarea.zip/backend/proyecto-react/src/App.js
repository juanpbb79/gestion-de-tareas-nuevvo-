import logo from "./logo.svg"
import "./App.css"
import { PrimerCoponente } from "./componentss/PrimerCoponente"

function App() {
  return (
    <div className="App">
      <header className="App-header">
        <img src={logo} className="App-logo" alt="logo" />
        <p>esto es un repaso par mi pagina juan pablo</p>

        <PrimerCoponente />
      </header>
    </div>
  )
}

export default App

