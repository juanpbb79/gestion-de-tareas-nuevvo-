"use client"

import  from "../frontend/src/index"

export default function SyntheticV0PageForDeployment() {
  return < />
}